import React, { useState, useMemo, useEffect } from "react";
import {
  ShoppingBag,
  X,
  Plus,
  Minus,
  MessageCircle,
  Sparkles,
  Search,
  Lock,
  LogOut,
  Trash2,
  Upload,
  Save,
} from "lucide-react";

const WHATSAPP_NUMBER = "224620054696";
const ADMIN_PASSWORD = "dede2026"; // à changer directement ici dans le code

const CATEGORIES = ["Mode", "Beauté", "Accessoires", "Maison"];
const ALL_CATEGORIES = ["Tout", ...CATEGORIES];

const DEFAULT_PRODUCTS = [
  { id: 1, name: "Robe soirée Aïcha", cat: "Mode", price: 250000, oldPrice: 300000, stock: 4, delivery: "2-3 jours", swatch: "from-[#5B2A45] to-[#8B4A6B]" },
  { id: 2, name: "Ensemble tailleur Awa", cat: "Mode", price: 320000, oldPrice: null, stock: 2, delivery: "3-5 jours", swatch: "from-[#3E2233] to-[#6B3A55]" },
  { id: 3, name: "Foulard soie imprimé", cat: "Mode", price: 85000, oldPrice: 100000, stock: 6, delivery: "1-2 jours", swatch: "from-[#7A4A5F] to-[#B07A8E]" },
  { id: 4, name: "Palette teint glow", cat: "Beauté", price: 120000, oldPrice: null, stock: 5, delivery: "2-3 jours", swatch: "from-[#8B6B2E] to-[#C9A961]" },
  { id: 5, name: "Huile capillaire karité", cat: "Beauté", price: 45000, oldPrice: 55000, stock: 8, delivery: "1-2 jours", swatch: "from-[#6B5220] to-[#A8843A]" },
  { id: 6, name: "Rouge à lèvres velours", cat: "Beauté", price: 55000, oldPrice: null, stock: 0, delivery: "2-3 jours", swatch: "from-[#5B1F2A] to-[#9B3D4E]" },
  { id: 7, name: "Sac à main croco", cat: "Accessoires", price: 280000, oldPrice: 350000, stock: 3, delivery: "3-5 jours", swatch: "from-[#2E2A1F] to-[#5A5238]" },
  { id: 8, name: "Boucles d'oreilles dorées", cat: "Accessoires", price: 65000, oldPrice: null, stock: 7, delivery: "1-2 jours", swatch: "from-[#8B7024] to-[#C9A961]" },
  { id: 9, name: "Lunettes de soleil glam", cat: "Accessoires", price: 95000, oldPrice: 130000, stock: 4, delivery: "2-3 jours", swatch: "from-[#231A1E] to-[#4A3540]" },
  { id: 10, name: "Bougie parfumée ambre", cat: "Maison", price: 40000, oldPrice: null, stock: 10, delivery: "1-2 jours", swatch: "from-[#4A3320] to-[#8B6B3E]" },
  { id: 11, name: "Coussin brodé fil d'or", cat: "Maison", price: 60000, oldPrice: 75000, stock: 5, delivery: "2-4 jours", swatch: "from-[#2E2436] to-[#5B4A6B]" },
  { id: 12, name: "Vase céramique doré", cat: "Maison", price: 75000, oldPrice: null, stock: 3, delivery: "3-5 jours", swatch: "from-[#3E2A28] to-[#7A5248]" },
];

const SWATCH_OPTIONS = [
  "from-[#5B2A45] to-[#8B4A6B]",
  "from-[#8B6B2E] to-[#C9A961]",
  "from-[#2E2A1F] to-[#5A5238]",
  "from-[#4A3320] to-[#8B6B3E]",
  "from-[#231A1E] to-[#4A3540]",
  "from-[#3E2233] to-[#6B3A55]",
];

function formatGNF(n) {
  return Number(n || 0).toLocaleString("fr-FR") + " GNF";
}

function newId(products) {
  return products.length ? Math.max(...products.map((p) => p.id)) + 1 : 1;
}

export default function DedeGlamour() {
  const [products, setProducts] = useState(DEFAULT_PRODUCTS);
  const [logo, setLogo] = useState(null);
  const [loaded, setLoaded] = useState(false);

  const [activeCat, setActiveCat] = useState("Tout");
  const [cart, setCart] = useState({});
  const [cartOpen, setCartOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);

  const [adminOpen, setAdminOpen] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [pwdInput, setPwdInput] = useState("");
  const [pwdError, setPwdError] = useState(false);
  const [draftProducts, setDraftProducts] = useState([]);
  const [draftLogo, setDraftLogo] = useState(null);
  const [saveState, setSaveState] = useState("idle"); // idle | saving | saved

  // Charger les données sauvegardées au démarrage
  useEffect(() => {
    try {
      const p = localStorage.getItem("dedeglamour_products");
      if (p) setProducts(JSON.parse(p));
    } catch (e) {}
    try {
      const l = localStorage.getItem("dedeglamour_logo");
      if (l) setLogo(l);
    } catch (e) {}
    setLoaded(true);
  }, []);

  const suggestions = useMemo(() => {
    if (!search.trim()) return [];
    const q = search.trim().toLowerCase();
    return products.filter((p) => p.name.toLowerCase().includes(q)).slice(0, 6);
  }, [search, products]);

  const filtered = useMemo(() => {
    const byCat = activeCat === "Tout" ? products : products.filter((p) => p.cat === activeCat);
    const q = search.trim().toLowerCase();
    return q ? byCat.filter((p) => p.name.toLowerCase().includes(q)) : byCat;
  }, [activeCat, search, products]);

  const cartItems = useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => ({ ...products.find((p) => p.id === Number(id)), qty }))
        .filter((i) => i.qty > 0 && i.id),
    [cart, products]
  );

  const totalItems = cartItems.reduce((s, i) => s + i.qty, 0);
  const totalPrice = cartItems.reduce((s, i) => s + i.qty * i.price, 0);

  function addToCart(id) {
    setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
  }
  function changeQty(id, delta) {
    setCart((c) => {
      const next = Math.max(0, (c[id] || 0) + delta);
      return { ...c, [id]: next };
    });
  }
  function selectSuggestion(p) {
    setSearch(p.name);
    setActiveCat("Tout");
    setShowSuggestions(false);
  }

  function sendOrder() {
    if (cartItems.length === 0) return;
    const lines = cartItems.map((i) => `• ${i.name} x${i.qty} — ${formatGNF(i.price * i.qty)}`);
    const message =
      `Bonjour DedeGlamour, je souhaite commander :\n\n` +
      lines.join("\n") +
      `\n\nTotal : ${formatGNF(totalPrice)}`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
  }

  // --- Admin ---
  function openAdmin() {
    setAdminOpen(true);
    setPwdInput("");
    setPwdError(false);
  }
  function closeAdmin() {
    setAdminOpen(false);
    setAuthed(false);
  }
  function submitPassword() {
    if (pwdInput === ADMIN_PASSWORD) {
      setAuthed(true);
      setDraftProducts(products.map((p) => ({ ...p })));
      setDraftLogo(logo);
    } else {
      setPwdError(true);
    }
  }
  function updateDraft(id, field, value) {
    setDraftProducts((list) => list.map((p) => (p.id === id ? { ...p, [field]: value } : p)));
  }
  function addDraftProduct() {
    setDraftProducts((list) => [
      ...list,
      {
        id: newId(list),
        name: "Nouveau produit",
        cat: CATEGORIES[0],
        price: 0,
        oldPrice: null,
        stock: 0,
        delivery: "2-3 jours",
        swatch: SWATCH_OPTIONS[list.length % SWATCH_OPTIONS.length],
      },
    ]);
  }
  function removeDraftProduct(id) {
    setDraftProducts((list) => list.filter((p) => p.id !== id));
  }
  function handleLogoFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setDraftLogo(reader.result);
    reader.readAsDataURL(file);
  }
  async function saveAll() {
    setSaveState("saving");
    const cleaned = draftProducts.map((p) => ({
      ...p,
      price: Number(p.price) || 0,
      oldPrice: p.oldPrice ? Number(p.oldPrice) : null,
      stock: Number(p.stock) || 0,
    }));
    try {
      localStorage.setItem("dedeglamour_products", JSON.stringify(cleaned));
      if (draftLogo !== logo) {
        localStorage.setItem("dedeglamour_logo", draftLogo || "");
      }
      setProducts(cleaned);
      setLogo(draftLogo);
      setSaveState("saved");
      setTimeout(() => setSaveState("idle"), 1800);
    } catch (e) {
      setSaveState("idle");
    }
  }

  return (
    <div className="min-h-screen bg-[#1C1420] text-[#F3EAE3]" style={{ fontFamily: "'Work Sans', sans-serif" }}>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link
        href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Work+Sans:wght@400;500;600&display=swap"
        rel="stylesheet"
      />

      {/* Header */}
      <header className="sticky top-0 z-30 backdrop-blur-md bg-[#1C1420]/90 border-b border-[#C9A961]/20">
        <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {logo ? (
              <img src={logo} alt="Logo DedeGlamour" className="w-9 h-9 rounded-full object-cover border border-[#C9A961]" />
            ) : (
              <div className="w-9 h-9 rounded-full border border-[#C9A961] flex items-center justify-center">
                <Sparkles size={16} className="text-[#C9A961]" />
              </div>
            )}
            <span style={{ fontFamily: "'Fraunces', serif" }} className="text-xl tracking-wide">
              DedeGlamour
            </span>
          </div>
          <button
            onClick={() => setCartOpen(true)}
            className="relative flex items-center gap-2 px-4 py-2 rounded-full border border-[#C9A961]/40 hover:border-[#C9A961] transition-colors text-sm"
          >
            <ShoppingBag size={16} />
            <span className="hidden sm:inline">Panier</span>
            {totalItems > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-[#C9A961] text-[#1C1420] text-[10px] font-semibold w-5 h-5 rounded-full flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-5 pt-14 pb-10 text-center">
        <p className="text-[#C9A961] text-xs tracking-[0.25em] uppercase mb-3">Boutique en ligne</p>
        <h1 style={{ fontFamily: "'Fraunces', serif" }} className="text-4xl sm:text-5xl leading-tight mb-4">
          Le glamour, livré <br className="hidden sm:block" /> jusqu'à chez toi
        </h1>
        <p className="text-[#F3EAE3]/60 max-w-md mx-auto text-sm">
          Mode, beauté, accessoires et déco — choisis tes articles, on finalise ta commande sur WhatsApp.
        </p>
        <div className="mt-6 h-px w-24 mx-auto bg-gradient-to-r from-transparent via-[#C9A961] to-transparent" />

        <div className="relative max-w-md mx-auto mt-8">
          <div className="flex items-center gap-2 bg-[#241A2A] border border-[#F3EAE3]/15 rounded-full px-4 py-2.5 focus-within:border-[#C9A961]/60 transition-colors">
            <Search size={16} className="text-[#F3EAE3]/40 flex-shrink-0" />
            <input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setShowSuggestions(true);
              }}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 120)}
              placeholder="Rechercher un produit…"
              className="w-full bg-transparent text-sm outline-none placeholder:text-[#F3EAE3]/35"
            />
            {search && (
              <button onClick={() => setSearch("")} aria-label="Effacer la recherche" className="text-[#F3EAE3]/40 hover:text-[#F3EAE3]/70 flex-shrink-0">
                <X size={15} />
              </button>
            )}
          </div>

          {showSuggestions && search.trim() && (
            <div className="absolute left-0 right-0 mt-2 bg-[#241A2A] border border-[#F3EAE3]/15 rounded-2xl overflow-hidden shadow-xl z-20 text-left">
              {suggestions.length === 0 ? (
                <p className="px-4 py-3 text-sm text-[#F3EAE3]/40">Aucun produit trouvé.</p>
              ) : (
                suggestions.map((p) => (
                  <button
                    key={p.id}
                    onMouseDown={() => selectSuggestion(p)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[#C9A961]/10 transition-colors text-left"
                  >
                    <div className={`w-8 h-8 rounded-md bg-gradient-to-br ${p.swatch} flex-shrink-0`} />
                    <span className="text-sm flex-1 truncate">{p.name}</span>
                    <span className="text-xs text-[#C9A961]/80">{p.cat}</span>
                  </button>
                ))
              )}
            </div>
          )}
        </div>
      </section>

      {/* Categories */}
      <div className="max-w-6xl mx-auto px-5 flex gap-2 overflow-x-auto pb-6 no-scrollbar">
        {ALL_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCat(cat)}
            className={`px-4 py-1.5 rounded-full text-sm whitespace-nowrap border transition-colors ${
              activeCat === cat ? "bg-[#C9A961] text-[#1C1420] border-[#C9A961]" : "border-[#F3EAE3]/20 text-[#F3EAE3]/70 hover:border-[#C9A961]/50"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Product grid */}
      <main className="max-w-6xl mx-auto px-5 pb-24 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map((p) => {
          const hasDiscount = p.oldPrice && p.oldPrice > p.price;
          const outOfStock = p.stock <= 0;
          return (
            <div key={p.id} className="group rounded-2xl overflow-hidden border border-[#F3EAE3]/10 bg-[#241A2A] flex flex-col">
              <div className={`relative h-32 bg-gradient-to-br ${p.swatch} flex items-center justify-center`}>
                <Sparkles size={22} className="text-white/40" />
                {hasDiscount && (
                  <span className="absolute top-2 left-2 bg-[#D63B3B] text-white text-[10px] font-semibold px-2 py-0.5 rounded-full">
                    -{Math.round(100 - (p.price / p.oldPrice) * 100)}%
                  </span>
                )}
                {outOfStock && (
                  <span className="absolute inset-0 bg-black/50 flex items-center justify-center text-xs font-medium">
                    Rupture de stock
                  </span>
                )}
              </div>
              <div className="p-3.5 flex flex-col flex-1">
                <span className="text-[10px] uppercase tracking-wider text-[#C9A961]/80 mb-1">{p.cat}</span>
                <h3 className="text-sm font-medium leading-snug mb-1">{p.name}</h3>
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="text-sm font-semibold">{formatGNF(p.price)}</span>
                  {hasDiscount && (
                    <span className="text-xs text-[#F3EAE3]/40 line-through">{formatGNF(p.oldPrice)}</span>
                  )}
                </div>
                <p className="text-[11px] text-[#F3EAE3]/45 mb-2">
                  {outOfStock ? "Indisponible" : `${p.stock} en stock`} · livraison {p.delivery}
                </p>
                <div className="mt-auto flex items-center justify-end">
                  <button
                    onClick={() => addToCart(p.id)}
                    disabled={outOfStock}
                    aria-label={`Ajouter ${p.name} au panier`}
                    className="w-8 h-8 rounded-full bg-[#C9A961] disabled:bg-[#C9A961]/25 disabled:cursor-not-allowed text-[#1C1420] flex items-center justify-center hover:bg-[#DDBD7E] transition-colors"
                  >
                    <Plus size={15} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </main>

      {/* Floating cart button (mobile) */}
      {totalItems > 0 && !cartOpen && (
        <button
          onClick={() => setCartOpen(true)}
          className="fixed bottom-5 left-1/2 -translate-x-1/2 bg-[#C9A961] text-[#1C1420] rounded-full px-5 py-3 shadow-lg flex items-center gap-2 text-sm font-medium z-30"
        >
          <ShoppingBag size={16} />
          Voir le panier · {formatGNF(totalPrice)}
        </button>
      )}

      {/* Admin access button */}
      <button
        onClick={openAdmin}
        aria-label="Espace administrateur"
        className="fixed bottom-5 right-5 w-10 h-10 rounded-full bg-[#241A2A] border border-[#F3EAE3]/15 flex items-center justify-center text-[#F3EAE3]/40 hover:text-[#C9A961] hover:border-[#C9A961]/50 transition-colors z-30"
      >
        <Lock size={15} />
      </button>

      {/* Cart drawer */}
      {cartOpen && (
        <div className="fixed inset-0 z-40 flex justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setCartOpen(false)} />
          <div className="relative w-full sm:w-96 h-full bg-[#241A2A] border-l border-[#C9A961]/20 flex flex-col animate-[slideIn_0.25s_ease-out]">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#F3EAE3]/10">
              <h2 style={{ fontFamily: "'Fraunces', serif" }} className="text-lg">
                Ton panier
              </h2>
              <button onClick={() => setCartOpen(false)} aria-label="Fermer le panier">
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
              {cartItems.length === 0 ? (
                <p className="text-[#F3EAE3]/50 text-sm text-center mt-10">Ton panier est vide pour l'instant.</p>
              ) : (
                cartItems.map((i) => (
                  <div key={i.id} className="flex items-center gap-3">
                    <div className={`w-14 h-14 rounded-lg bg-gradient-to-br ${i.swatch} flex-shrink-0`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{i.name}</p>
                      <p className="text-xs text-[#F3EAE3]/50">{formatGNF(i.price)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => changeQty(i.id, -1)} className="w-6 h-6 rounded-full border border-[#F3EAE3]/20 flex items-center justify-center">
                        <Minus size={12} />
                      </button>
                      <span className="text-sm w-4 text-center">{i.qty}</span>
                      <button onClick={() => changeQty(i.id, 1)} className="w-6 h-6 rounded-full border border-[#F3EAE3]/20 flex items-center justify-center">
                        <Plus size={12} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="px-5 py-4 border-t border-[#F3EAE3]/10 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#F3EAE3]/60">Total</span>
                <span className="font-semibold text-base">{formatGNF(totalPrice)}</span>
              </div>
              <button
                onClick={sendOrder}
                disabled={cartItems.length === 0}
                className="w-full flex items-center justify-center gap-2 bg-[#25D366] disabled:bg-[#25D366]/30 disabled:cursor-not-allowed text-[#0B2E1B] font-medium py-3 rounded-full text-sm transition-colors"
              >
                <MessageCircle size={17} />
                Commander via WhatsApp
              </button>
              <p className="text-[10px] text-center text-[#F3EAE3]/40">Ta commande s'ouvre dans WhatsApp pour confirmation.</p>
            </div>
          </div>
        </div>
      )}

      {/* Admin drawer */}
      {adminOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/60" onClick={closeAdmin} />
          <div className="relative w-full sm:w-[440px] h-full bg-[#241A2A] border-l border-[#C9A961]/30 flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#F3EAE3]/10">
              <h2 style={{ fontFamily: "'Fraunces', serif" }} className="text-lg flex items-center gap-2">
                <Lock size={16} className="text-[#C9A961]" />
                Espace administrateur
              </h2>
              <button onClick={closeAdmin} aria-label="Fermer">
                <X size={20} />
              </button>
            </div>

            {!authed ? (
              <div className="flex-1 flex flex-col items-center justify-center px-8 gap-4">
                <p className="text-sm text-[#F3EAE3]/60 text-center">
                  Entre le mot de passe administrateur pour gérer le logo et les produits.
                </p>
                <input
                  type="password"
                  value={pwdInput}
                  onChange={(e) => {
                    setPwdInput(e.target.value);
                    setPwdError(false);
                  }}
                  onKeyDown={(e) => e.key === "Enter" && submitPassword()}
                  placeholder="Mot de passe"
                  className="w-full bg-[#1C1420] border border-[#F3EAE3]/15 rounded-full px-4 py-2.5 text-sm outline-none focus:border-[#C9A961]/60"
                />
                {pwdError && <p className="text-xs text-[#E07A6B]">Mot de passe incorrect.</p>}
                <button onClick={submitPassword} className="w-full bg-[#C9A961] text-[#1C1420] font-medium py-2.5 rounded-full text-sm">
                  Entrer
                </button>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto px-5 py-4 space-y-6">
                  {/* Logo */}
                  <div>
                    <p className="text-xs uppercase tracking-wider text-[#C9A961]/80 mb-2">Logo de la boutique</p>
                    <div className="flex items-center gap-3">
                      {draftLogo ? (
                        <img src={draftLogo} alt="Aperçu logo" className="w-12 h-12 rounded-full object-cover border border-[#C9A961]" />
                      ) : (
                        <div className="w-12 h-12 rounded-full border border-[#C9A961]/40 flex items-center justify-center">
                          <Sparkles size={16} className="text-[#C9A961]/50" />
                        </div>
                      )}
                      <label className="flex items-center gap-2 text-xs px-3 py-2 rounded-full border border-[#F3EAE3]/20 hover:border-[#C9A961]/50 cursor-pointer transition-colors">
                        <Upload size={13} />
                        Changer le logo
                        <input type="file" accept="image/*" onChange={handleLogoFile} className="hidden" />
                      </label>
                    </div>
                  </div>

                  {/* Products */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs uppercase tracking-wider text-[#C9A961]/80">Produits ({draftProducts.length})</p>
                      <button onClick={addDraftProduct} className="flex items-center gap-1 text-xs text-[#C9A961] hover:text-[#DDBD7E]">
                        <Plus size={13} /> Ajouter
                      </button>
                    </div>

                    <div className="space-y-3">
                      {draftProducts.map((p) => (
                        <div key={p.id} className="bg-[#1C1420] rounded-xl p-3 border border-[#F3EAE3]/10 space-y-2">
                          <div className="flex items-center gap-2">
                            <input
                              value={p.name}
                              onChange={(e) => updateDraft(p.id, "name", e.target.value)}
                              placeholder="Nom du produit"
                              className="flex-1 bg-transparent border-b border-[#F3EAE3]/15 text-sm outline-none focus:border-[#C9A961]/60 py-1"
                            />
                            <button onClick={() => removeDraftProduct(p.id)} aria-label="Supprimer" className="text-[#F3EAE3]/30 hover:text-[#E07A6B]">
                              <Trash2 size={15} />
                            </button>
                          </div>

                          <select
                            value={p.cat}
                            onChange={(e) => updateDraft(p.id, "cat", e.target.value)}
                            className="w-full bg-[#241A2A] border border-[#F3EAE3]/15 rounded-lg text-xs px-2 py-1.5 outline-none"
                          >
                            {CATEGORIES.map((c) => (
                              <option key={c} value={c}>
                                {c}
                              </option>
                            ))}
                          </select>

                          <div className="grid grid-cols-2 gap-2">
                            <label className="text-[10px] text-[#F3EAE3]/40">
                              Prix actuel (GNF)
                              <input
                                type="number"
                                value={p.price}
                                onChange={(e) => updateDraft(p.id, "price", e.target.value)}
                                className="w-full mt-0.5 bg-[#241A2A] border border-[#F3EAE3]/15 rounded-lg text-xs px-2 py-1.5 outline-none"
                              />
                            </label>
                            <label className="text-[10px] text-[#F3EAE3]/40">
                              Ancien prix (barré, optionnel)
                              <input
                                type="number"
                                value={p.oldPrice || ""}
                                onChange={(e) => updateDraft(p.id, "oldPrice", e.target.value ? e.target.value : null)}
                                placeholder="—"
                                className="w-full mt-0.5 bg-[#241A2A] border border-[#F3EAE3]/15 rounded-lg text-xs px-2 py-1.5 outline-none"
                              />
                            </label>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <label className="text-[10px] text-[#F3EAE3]/40">
                              Quantité en stock
                              <input
                                type="number"
                                value={p.stock}
                                onChange={(e) => updateDraft(p.id, "stock", e.target.value)}
                                className="w-full mt-0.5 bg-[#241A2A] border border-[#F3EAE3]/15 rounded-lg text-xs px-2 py-1.5 outline-none"
                              />
                            </label>
                            <label className="text-[10px] text-[#F3EAE3]/40">
                              Délai de livraison
                              <input
                                value={p.delivery}
                                onChange={(e) => updateDraft(p.id, "delivery", e.target.value)}
                                placeholder="ex : 2-3 jours"
                                className="w-full mt-0.5 bg-[#241A2A] border border-[#F3EAE3]/15 rounded-lg text-xs px-2 py-1.5 outline-none"
                              />
                            </label>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="px-5 py-4 border-t border-[#F3EAE3]/10 flex items-center gap-2">
                  <button
                    onClick={saveAll}
                    disabled={saveState === "saving"}
                    className="flex-1 flex items-center justify-center gap-2 bg-[#C9A961] text-[#1C1420] font-medium py-2.5 rounded-full text-sm transition-colors disabled:opacity-60"
                  >
                    <Save size={15} />
                    {saveState === "saving" ? "Enregistrement…" : saveState === "saved" ? "Enregistré ✓" : "Enregistrer"}
                  </button>
                  <button
                    onClick={closeAdmin}
                    aria-label="Se déconnecter"
                    className="w-10 h-10 rounded-full border border-[#F3EAE3]/15 flex items-center justify-center text-[#F3EAE3]/50 hover:text-[#E07A6B]"
                  >
                    <LogOut size={16} />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }
        .no-scrollbar::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}
